/**
 * ============================================================
 *  SUVISHESH YASHOM LLP — Google Sheets Backend (Apps Script)
 * ============================================================
 *
 *  This script turns a Google Sheet into a tiny backend API for
 *  the website's Contact form and Shipment Tracker.
 *
 *  SETUP — do this once:
 *  ----------------------------------------------------------
 *  1. Create a new Google Sheet (sheets.new).
 *
 *  2. Create two tabs (sheet names must match exactly):
 *       - "Leads"     — columns: Timestamp | Name | Company | Email | Phone | Message | Status
 *       - "Shipments" — columns: TrackingID | Status | ETA | Step1 | Step2 | Step3 | Step4 | Step5
 *
 *  3. Open Extensions → Apps Script. Delete any boilerplate code
 *     and paste THIS ENTIRE FILE in.
 *
 *  4. Click Deploy → New deployment.
 *       - Type: "Web app"
 *       - Execute as: "Me"
 *       - Who has access: "Anyone"
 *     Click Deploy, authorize the permissions when prompted.
 *
 *  5. Copy the generated Web App URL — it looks like:
 *       https://script.google.com/macros/s/XXXXXXXX/exec
 *
 *  6. Paste that URL into the website's .env file as:
 *       VITE_SHEETS_API_URL=https://script.google.com/macros/s/XXXXXXXX/exec
 *
 *  7. Whenever you edit this script again, you MUST create a
 *     "New deployment" (or "Manage deployments" → edit → new
 *     version) for the changes to go live.
 *
 *  8. To verify the connection at any time, open this in a
 *     browser (replace with your own deployment URL):
 *       https://script.google.com/macros/s/XXXXXXXX/exec?action=test
 *     It should return something like:
 *       {"success":true,"spreadsheet":"My Sheet","sheets":["Leads","Shipments"]}
 * ============================================================
 */

const LEADS_SHEET     = "Leads";
const SHIPMENTS_SHEET = "Shipments";

/* ── Handle POST requests (Contact form submissions) ── */
function doPost(e) {
  try {
    const data   = JSON.parse(e.postData.contents);
    const action = data.action || "lead";

    if (action === "lead") {
      return addLead(data);
    }

    return jsonResponse({ success: false, error: "Unknown action" });
  } catch (err) {
    return jsonResponse({ success: false, error: err.message, stack: err.stack });
  }
}

/* ── Handle GET requests (Shipment tracking + connection test) ── */
function doGet(e) {
  try {
    const action = (e.parameter.action || "").toLowerCase();

    if (action === "track") {
      return trackShipment(e.parameter.id || "");
    }

    if (action === "test") {
      const ss = SpreadsheetApp.getActiveSpreadsheet();
      return jsonResponse({
        success: true,
        message: "Backend is connected!",
        spreadsheet: ss.getName(),
        sheets: ss.getSheets().map(s => s.getName())
      });
    }

    return jsonResponse({ success: false, error: "Unknown action. Try ?action=test" });
  } catch (err) {
    return jsonResponse({ success: false, error: err.message, stack: err.stack });
  }
}

/* ── Add a new lead row to the "Leads" sheet ── */
function addLead(data) {
  const sheet = getSheet(LEADS_SHEET, [
    "Timestamp", "Name", "Company", "Email", "Phone", "Message", "Status"
  ]);

  sheet.appendRow([
    new Date(),
    data.name    || "",
    data.company || "",
    data.email   || "",
    data.phone   || "",
    data.message || "",
    "New"
  ]);

  SpreadsheetApp.flush();

  return jsonResponse({ success: true, message: "Lead saved" });
}

/* ── Look up a shipment by Tracking ID in the "Shipments" sheet ── */
function trackShipment(id) {
  const sheet = getSheet(SHIPMENTS_SHEET, [
    "TrackingID", "Status", "ETA", "Step1", "Step2", "Step3", "Step4", "Step5"
  ]);

  const rows = sheet.getDataRange().getValues();
  const header = rows[0];

  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (String(row[0]).trim().toUpperCase() === String(id).trim().toUpperCase()) {
      const steps = [];
      for (let c = 3; c < row.length; c++) {
        if (row[c]) steps.push(String(row[c]));
      }
      return jsonResponse({
        success: true,
        found: true,
        trackingId: row[0],
        status: row[1],
        eta: row[2],
        steps: steps
      });
    }
  }

  return jsonResponse({ success: true, found: false });
}

/* ── Helper: get sheet by name, create with headers if missing ── */
function getSheet(name, headers) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.appendRow(headers);
    sheet.getRange(1, 1, 1, headers.length).setFontWeight("bold");
  }
  return sheet;
}

/* ── Helper: JSON response with CORS headers ── */
function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
