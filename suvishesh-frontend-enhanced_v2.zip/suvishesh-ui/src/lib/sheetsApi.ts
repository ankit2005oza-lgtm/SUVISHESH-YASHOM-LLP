/**
 * ============================================================
 *  Google Sheets backend client
 * ============================================================
 *  Talks to the Google Apps Script Web App (see /apps-script/Code.gs)
 *  Configure the deployed URL via the VITE_SHEETS_API_URL env var.
 * ============================================================
 */

const API_URL = import.meta.env.VITE_SHEETS_API_URL as string | undefined;

export interface LeadPayload {
  name: string;
  company?: string;
  email: string;
  phone?: string;
  message: string;
}

export interface TrackResult {
  success: boolean;
  found?: boolean;
  trackingId?: string;
  status?: string;
  eta?: string;
  steps?: string[];
  error?: string;
}

/** Returns true if a Sheets backend URL has been configured. */
export function isBackendConfigured(): boolean {
  return Boolean(API_URL && API_URL.startsWith("http"));
}

/**
 * Submit a contact form lead to the Google Sheet.
 * Uses `text/plain` content-type + no-cors-friendly settings so the
 * request works against Apps Script Web Apps without extra setup.
 */
export async function submitLead(payload: LeadPayload): Promise<{ success: boolean; error?: string }> {
  if (!isBackendConfigured()) {
    return { success: false, error: "not-configured" };
  }

  try {
    const res = await fetch(API_URL as string, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify({ action: "lead", ...payload }),
    });
    const json = await res.json();
    return { success: !!json.success, error: json.error };
  } catch (err) {
    return { success: false, error: (err as Error).message };
  }
}

/**
 * Look up a shipment by tracking ID.
 */
export async function trackShipment(id: string): Promise<TrackResult> {
  if (!isBackendConfigured()) {
    return { success: false, error: "not-configured" };
  }

  try {
    const url = `${API_URL}?action=track&id=${encodeURIComponent(id)}`;
    const res = await fetch(url);
    const json = await res.json();
    return json as TrackResult;
  } catch (err) {
    return { success: false, error: (err as Error).message };
  }
}
