/**
 * Illustrated logistics scenes (pure SVG, no external files, work offline).
 * They act as the default "photos" across the site. To use real photographs,
 * drop JPGs into /public/images (see README) — <Photo> picks them up
 * automatically and falls back to these scenes if a file is missing.
 */
import React from "react";

/* deterministic pseudo-random so SSR / re-renders never change the artwork */
function rng(seed: number) {
  let s = seed;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

const svgProps = {
  viewBox: "0 0 1600 900",
  preserveAspectRatio: "xMidYMid slice" as const,
  className: "absolute inset-0 h-full w-full",
  "aria-hidden": true,
};

/* ───────────────────────── Truck ───────────────────────── */
function Truck({ scale = 1, label = true }: { scale?: number; label?: boolean }) {
  return (
    <g transform={`scale(${scale})`}>
      {/* headlight beam */}
      <polygon points="414,-52 760,-120 760,10 414,-34" fill="url(#beam)" opacity="0.55" />
      {/* trailer */}
      <rect x="0" y="-160" width="300" height="142" rx="8" fill="url(#trailer)" />
      <rect x="0" y="-100" width="300" height="22" fill="#0EA5E9" />
      <rect x="0" y="-78" width="300" height="6" fill="#6366F1" />
      {label && (
        <text x="150" y="-118" textAnchor="middle" fontFamily="Montserrat, sans-serif" fontWeight="800" fontSize="19" letterSpacing="2" fill="#0B1120">
          SUVISHESH YASHOM
        </text>
      )}
      {[40, 80, 120, 160, 200, 240].map((x) => (
        <line key={x} x1={x} y1="-158" x2={x} y2="-104" stroke="#cbd5e1" strokeWidth="1.5" />
      ))}
      {/* chassis */}
      <rect x="-4" y="-20" width="424" height="12" rx="4" fill="#0f172a" />
      {/* cab */}
      <path d="M304 -18 L304 -128 Q304 -138 314 -138 L352 -138 Q362 -138 368 -130 L402 -80 L418 -74 L418 -18 Z" fill="url(#cab)" />
      <path d="M326 -122 L352 -122 L388 -80 L326 -80 Z" fill="#bae6fd" opacity="0.85" />
      <path d="M326 -122 L338 -122 L322 -80 L326 -80 Z" fill="#fff" opacity="0.35" />
      <rect x="412" y="-60" width="10" height="14" rx="3" fill="#fde68a" />
      <rect x="306" y="-60" width="106" height="4" fill="#0B1120" opacity="0.25" />
      {/* wheels */}
      {[52, 108, 350].map((x) => (
        <g key={x} transform={`translate(${x} -12)`}>
          <circle r="26" fill="#0b0f19" />
          <circle r="13" fill="#475569" />
          <circle r="5" fill="#94a3b8" />
        </g>
      ))}
    </g>
  );
}

function Van() {
  return (
    <g>
      <polygon points="262,-40 560,-100 560,10 262,-22" fill="url(#beam)" opacity="0.5" />
      <path d="M0 -20 L0 -118 Q0 -126 8 -126 L170 -126 L170 -20 Z" fill="url(#trailer)" />
      <path d="M170 -126 L214 -126 Q224 -126 230 -116 L256 -74 L262 -70 L262 -20 L170 -20 Z" fill="url(#cab)" />
      <path d="M182 -116 L212 -116 L240 -74 L182 -74 Z" fill="#bae6fd" opacity="0.85" />
      <rect x="0" y="-70" width="170" height="14" fill="#0EA5E9" />
      <text x="85" y="-90" textAnchor="middle" fontFamily="Montserrat, sans-serif" fontWeight="800" fontSize="13" letterSpacing="1.5" fill="#0B1120">SUVISHESH</text>
      {[48, 214].map((x) => (
        <g key={x} transform={`translate(${x} -10)`}>
          <circle r="22" fill="#0b0f19" /><circle r="11" fill="#475569" /><circle r="4" fill="#94a3b8" />
        </g>
      ))}
    </g>
  );
}

function Defs({ id }: { id: string }) {
  return (
    <defs>
      <linearGradient id="trailer" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#ffffff" /><stop offset="1" stopColor="#cbd5e1" />
      </linearGradient>
      <linearGradient id="cab" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#38BDF8" /><stop offset="1" stopColor="#4F46E5" />
      </linearGradient>
      <linearGradient id="beam" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0" stopColor="#fef9c3" stopOpacity="0.9" /><stop offset="1" stopColor="#fef9c3" stopOpacity="0" />
      </linearGradient>
      <radialGradient id={`${id}-glow`}>
        <stop offset="0" stopColor="#fbbf24" stopOpacity="0.95" /><stop offset="0.4" stopColor="#f97316" stopOpacity="0.35" /><stop offset="1" stopColor="#f97316" stopOpacity="0" />
      </radialGradient>
    </defs>
  );
}

function Skyline({ seed, y, h, color, count = 34, windows = false }: { seed: number; y: number; h: number; color: string; count?: number; windows?: boolean }) {
  const r = rng(seed);
  let x = -20;
  const out: React.ReactNode[] = [];
  for (let i = 0; i < count; i++) {
    const w = 40 + r() * 70;
    const bh = h * (0.3 + r() * 0.7);
    out.push(<rect key={`b${i}`} x={x} y={y - bh} width={w} height={bh + 4} fill={color} />);
    if (windows) {
      for (let wy = y - bh + 10; wy < y - 8; wy += 14) {
        for (let wx = x + 6; wx < x + w - 8; wx += 12) {
          if (r() > 0.72) out.push(<rect key={`w${i}-${wx}-${wy}`} x={wx} y={wy} width="5" height="7" fill="#fde68a" opacity={0.35 + r() * 0.5} />);
        }
      }
    }
    x += w + 2;
  }
  return <>{out}</>;
}

/* ───────────────────────── Scenes ───────────────────────── */

export function HighwayScene() {
  const r = rng(7);
  return (
    <svg {...svgProps}>
      <Defs id="hw" />
      <defs>
        <linearGradient id="hw-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#070b17" /><stop offset="0.45" stopColor="#1e2a5a" /><stop offset="0.78" stopColor="#7c3a6b" /><stop offset="1" stopColor="#f59e0b" />
        </linearGradient>
      </defs>
      <rect width="1600" height="900" fill="url(#hw-sky)" />
      {Array.from({ length: 50 }).map((_, i) => (
        <circle key={i} cx={r() * 1600} cy={r() * 330} r={r() * 1.4 + 0.3} fill="#fff" opacity={0.3 + r() * 0.6} />
      ))}
      <circle cx="1180" cy="560" r="260" fill="url(#hw-glow)" />
      <circle cx="1180" cy="560" r="70" fill="#fde68a" opacity="0.95" />
      <g transform="translate(0 -120)">
      <g className="parallax-slow"><Skyline seed={3} y={640} h={230} color="#1b2147" count={40} /></g>
      <g className="parallax-mid"><Skyline seed={11} y={680} h={260} color="#10152d" count={40} windows /></g>
      {/* ground */}
      <rect y="660" width="1600" height="420" fill="#0a0e1b" />
      <rect y="700" width="1600" height="380" fill="#151c30" />
      <rect y="700" width="1600" height="5" fill="#334155" />
      <rect y="730" width="1600" height="3" fill="#fbbf24" opacity="0.5" />
      <line x1="0" y1="805" x2="1600" y2="805" stroke="#e2e8f0" strokeWidth="5" strokeDasharray="70 55" className="lane-dash" />
      <rect y="882" width="1600" height="3" fill="#334155" />
      {/* far truck */}
      <g transform="translate(0 735)"><g className="drive-r-slow"><Truck scale={0.5} label={false} /></g></g>
      {/* hero truck */}
      <g transform="translate(0 868)"><g className="drive-r"><Truck /></g></g>
      {/* lamp posts */}
      {[180, 620, 1060, 1500].map((x) => (
        <g key={x}>
          <rect x={x} y="560" width="5" height="145" fill="#0b1020" />
          <rect x={x - 30} y="558" width="38" height="5" fill="#0b1020" />
          <circle cx={x - 28} cy="566" r="22" fill="#fde68a" opacity="0.18" />
          <circle cx={x - 28} cy="565" r="4" fill="#fef3c7" />
        </g>
      ))}
      </g>
    </svg>
  );
}

export function WarehouseScene() {
  const r = rng(21);
  const boxes = (x: number, y: number, cols: number) =>
    Array.from({ length: cols }).map((_, i) => (
      <rect key={`${x}-${y}-${i}`} x={x + i * 58} y={y - 44} width="52" height="44" rx="2" fill={["#d4a373", "#c08457", "#e0b98a"][Math.floor(r() * 3)]} stroke="#7c5230" strokeWidth="1.5" />
    ));
  return (
    <svg {...svgProps}>
      <Defs id="wh" />
      <defs>
        <linearGradient id="wh-bg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0b1120" /><stop offset="1" stopColor="#1c2742" />
        </linearGradient>
        <linearGradient id="wh-floor" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1f2937" /><stop offset="1" stopColor="#0b1120" />
        </linearGradient>
      </defs>
      <rect width="1600" height="900" fill="url(#wh-bg)" />
      {/* ceiling lights */}
      {[200, 520, 840, 1160, 1480].map((x) => (
        <g key={x}>
          <rect x={x - 70} y="70" width="140" height="10" rx="3" fill="#fef3c7" />
          <polygon points={`${x - 70},80 ${x + 70},80 ${x + 190},520 ${x - 190},520`} fill="#fde68a" opacity="0.06" />
        </g>
      ))}
      {/* back wall dock doors */}
      <rect y="300" width="1600" height="330" fill="#16213a" />
      {[120, 520, 920, 1320].map((x) => (
        <g key={x}>
          <rect x={x} y="340" width="220" height="250" fill="#0b1120" stroke="#334155" strokeWidth="4" />
          {Array.from({ length: 11 }).map((_, i) => (
            <line key={i} x1={x} y1={350 + i * 12} x2={x + 220} y2={350 + i * 12} stroke="#475569" strokeWidth="2" />
          ))}
          <rect x={x + 85} y="310" width="50" height="22" rx="3" fill="#0EA5E9" />
        </g>
      ))}
      {/* racks */}
      {[40, 1080].map((x) => (
        <g key={x}>
          {[560, 470, 380].map((y) => (
            <g key={y}>
              <rect x={x} y={y} width="480" height="8" fill="#38BDF8" opacity="0.9" />
              {boxes(x + 10, y, 8)}
            </g>
          ))}
          {[0, 160, 320, 472].map((dx) => (<rect key={dx} x={x + dx} y="330" width="8" height="260" fill="#fb923c" />))}
        </g>
      ))}
      {/* floor */}
      <rect y="620" width="1600" height="280" fill="url(#wh-floor)" />
      <line x1="0" y1="700" x2="1600" y2="700" stroke="#fbbf24" strokeWidth="5" opacity="0.7" strokeDasharray="40 24" />
      <line x1="0" y1="820" x2="1600" y2="820" stroke="#fbbf24" strokeWidth="6" opacity="0.5" />
      {/* pallets stack foreground */}
      <g transform="translate(560 800)">
        {[0, 1, 2].map((row) => (
          <g key={row}>
            {[0, 1, 2].map((c) => (
              <rect key={c} x={c * 70} y={-row * 52 - 52} width="66" height="48" rx="2" fill="#d4a373" stroke="#7c5230" strokeWidth="1.5" />
            ))}
          </g>
        ))}
        <rect x="-6" y="0" width="222" height="12" fill="#92400e" />
      </g>
      {/* forklift */}
      <g transform="translate(0 790)"><g className="drive-r-fork">
        <rect x="0" y="-90" width="110" height="60" rx="8" fill="#f59e0b" />
        <rect x="14" y="-84" width="56" height="40" fill="#fde68a" opacity="0.5" />
        <rect x="108" y="-190" width="10" height="160" fill="#475569" />
        <rect x="112" y="-60" width="70" height="8" fill="#94a3b8" />
        <rect x="118" y="-112" width="56" height="52" rx="2" fill="#d4a373" stroke="#7c5230" strokeWidth="1.5" />
        <circle cx="26" cy="-22" r="22" fill="#0b0f19" /><circle cx="26" cy="-22" r="9" fill="#475569" />
        <circle cx="90" cy="-18" r="16" fill="#0b0f19" /><circle cx="90" cy="-18" r="6" fill="#475569" />
      </g></g>
    </svg>
  );
}

export function PortScene() {
  const colors = ["#ef4444", "#0EA5E9", "#f59e0b", "#10B981", "#6366F1", "#f97316", "#e11d48"];
  const r = rng(5);
  const stack = (x: number, y: number, cols: number, rows: number) =>
    Array.from({ length: rows }).flatMap((_, ry) =>
      Array.from({ length: cols }).map((__, cx) => (
        <g key={`${x}-${y}-${ry}-${cx}`}>
          <rect x={x + cx * 84} y={y - (ry + 1) * 40} width="80" height="38" fill={colors[Math.floor(r() * colors.length)]} />
          {[10, 24, 38, 52, 66].map((d) => (<line key={d} x1={x + cx * 84 + d} y1={y - (ry + 1) * 40 + 4} x2={x + cx * 84 + d} y2={y - ry * 40 - 6} stroke="#000" opacity="0.18" />))}
        </g>
      ))
    );
  return (
    <svg {...svgProps}>
      <Defs id="pt" />
      <defs>
        <linearGradient id="pt-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0b1a3a" /><stop offset="0.6" stopColor="#3b5b9a" /><stop offset="1" stopColor="#fbbf24" />
        </linearGradient>
        <linearGradient id="pt-sea" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1e3a5f" /><stop offset="1" stopColor="#0b1120" />
        </linearGradient>
      </defs>
      <rect width="1600" height="900" fill="url(#pt-sky)" />
      <circle cx="400" cy="520" r="220" fill="url(#pt-glow)" />
      <rect y="520" width="1600" height="380" fill="url(#pt-sea)" />
      {Array.from({ length: 14 }).map((_, i) => (
        <rect key={i} x={r() * 1500} y={540 + i * 22} width={80 + r() * 160} height="2" fill="#fde68a" opacity="0.25" />
      ))}
      {/* ship */}
      <g className="ship-bob" transform="translate(760 540)">
        <path d="M0 0 L640 0 L600 70 L40 70 Z" fill="#0f172a" />
        <rect x="0" y="-8" width="640" height="10" fill="#dc2626" />
        {Array.from({ length: 3 }).flatMap((_, ry) => Array.from({ length: 7 }).map((__, cx) => (
          <rect key={`${ry}-${cx}`} x={30 + cx * 66} y={-48 - ry * 36} width="62" height="34" fill={colors[(ry * 7 + cx) % colors.length]} />
        )))}
        <rect x="540" y="-170" width="70" height="165" fill="#e2e8f0" />
        <rect x="552" y="-150" width="46" height="14" fill="#38BDF8" />
      </g>
      {/* quay */}
      <rect y="690" width="1600" height="210" fill="#111827" />
      <rect y="690" width="1600" height="8" fill="#334155" />
      {stack(40, 860, 6, 3)}
      {stack(1060, 860, 6, 4)}
      {/* gantry crane */}
      <g>
        <rect x="620" y="180" width="14" height="520" fill="#f59e0b" />
        <rect x="900" y="180" width="14" height="520" fill="#f59e0b" />
        <rect x="560" y="170" width="520" height="22" fill="#f59e0b" />
        <rect x="590" y="260" width="400" height="12" fill="#d97706" />
        <g className="crane-trolley">
          <rect x="0" y="192" width="46" height="28" fill="#475569" />
          <line x1="23" y1="220" x2="23" y2="340" stroke="#cbd5e1" strokeWidth="3" />
          <rect x="-8" y="340" width="62" height="34" fill="#ef4444" />
        </g>
      </g>
    </svg>
  );
}

export function LastMileScene() {
  const r = rng(13);
  const houses = Array.from({ length: 9 }).map((_, i) => {
    const x = i * 190 - 30;
    const h = 150 + r() * 80;
    return (
      <g key={i}>
        <rect x={x} y={640 - h} width="150" height={h} fill={["#1e293b", "#273449", "#312e5a"][i % 3]} />
        <polygon points={`${x - 10},${640 - h} ${x + 75},${640 - h - 60} ${x + 160},${640 - h}`} fill="#0f172a" />
        {[0, 1].map((c) => (
          <rect key={c} x={x + 28 + c * 62} y={640 - h + 34} width="34" height="42" fill="#fde68a" opacity={0.4 + r() * 0.55} />
        ))}
        <rect x={x + 62} y="580" width="28" height="60" fill="#0b1120" />
      </g>
    );
  });
  return (
    <svg {...svgProps}>
      <Defs id="lm" />
      <defs>
        <linearGradient id="lm-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0b1120" /><stop offset="0.6" stopColor="#3730a3" /><stop offset="1" stopColor="#fb7185" />
        </linearGradient>
      </defs>
      <rect width="1600" height="900" fill="url(#lm-sky)" />
      <circle cx="1300" cy="520" r="200" fill="url(#lm-glow)" />
      {houses}
      <rect y="640" width="1600" height="260" fill="#111827" />
      <rect y="640" width="1600" height="8" fill="#475569" />
      <line x1="0" y1="790" x2="1600" y2="790" stroke="#e2e8f0" strokeWidth="5" strokeDasharray="60 50" className="lane-dash" />
      <g transform="translate(0 770)"><g className="drive-r"><Van /></g></g>
      {/* destination pin */}
      <g transform="translate(1240 520)">
        <ellipse cx="0" cy="130" rx="40" ry="10" fill="#000" opacity="0.35" />
        <circle cx="0" cy="130" r="30" fill="none" stroke="#38BDF8" strokeWidth="3" className="pin-ring" />
        <g className="pin-bounce">
          <path d="M0 110 C-44 60 -44 0 0 0 C44 0 44 60 0 110 Z" fill="#38BDF8" />
          <circle cx="0" cy="42" r="16" fill="#0B1120" />
        </g>
      </g>
    </svg>
  );
}

export function NetworkScene() {
  const city = (x: number, y: number) => ({ x: x * 8 + 380, y: y * 8 + 40 });
  const outline = "38,4 46,6 52,14 62,18 70,24 78,26 90,30 88,36 78,36 72,34 68,40 66,48 62,52 58,66 52,80 48,92 44,80 38,66 34,56 28,50 22,46 16,44 22,38 28,30 30,22 34,14"
    .split(" ").map((p) => { const [a, b] = p.split(",").map(Number); const c = city(a, b); return `${c.x},${c.y}`; }).join(" ");
  const cities = { Delhi: city(46, 24), Jaipur: city(38, 30), Lucknow: city(55, 30), Ahmedabad: city(28, 40), Kolkata: city(68, 40), Mumbai: city(28, 52), Hyderabad: city(46, 58), Bengaluru: city(44, 72), Chennai: city(52, 74) };
  const links: [keyof typeof cities, keyof typeof cities][] = [["Delhi", "Jaipur"], ["Delhi", "Lucknow"], ["Delhi", "Mumbai"], ["Delhi", "Kolkata"], ["Mumbai", "Bengaluru"], ["Hyderabad", "Chennai"], ["Mumbai", "Hyderabad"], ["Kolkata", "Chennai"], ["Ahmedabad", "Mumbai"], ["Bengaluru", "Chennai"]];
  const dots: React.ReactNode[] = [];
  for (let gx = 380; gx < 1100; gx += 16) for (let gy = 40; gy < 800; gy += 16) dots.push(<circle key={`${gx}-${gy}`} cx={gx} cy={gy} r="2" fill="#38BDF8" />);
  return (
    <svg {...svgProps}>
      <defs>
        <clipPath id="in-clip"><polygon points={outline} /></clipPath>
        <radialGradient id="nt-bg" cx="0.6" cy="0.45" r="0.8"><stop offset="0" stopColor="#1e2a5a" /><stop offset="1" stopColor="#070b17" /></radialGradient>
      </defs>
      <rect width="1600" height="900" fill="url(#nt-bg)" />
      <g transform="translate(150 20)">
        <g clipPath="url(#in-clip)" opacity="0.4">{dots}</g>
        <polygon points={outline} fill="none" stroke="#38BDF8" strokeWidth="2" opacity="0.5" />
        {links.map(([a, b], i) => {
          const A = cities[a], B = cities[b];
          const mx = (A.x + B.x) / 2, my = Math.min(A.y, B.y) - 50;
          return <path key={i} d={`M${A.x} ${A.y} Q${mx} ${my} ${B.x} ${B.y}`} fill="none" stroke="#818CF8" strokeWidth="2.5" strokeDasharray="6 8" className="arc-flow" />;
        })}
        {Object.entries(cities).map(([n, c]) => (
          <g key={n}>
            <circle cx={c.x} cy={c.y} r="16" fill="#38BDF8" opacity="0.25" className="pin-ring" />
            <circle cx={c.x} cy={c.y} r="6" fill="#38BDF8" />
            <text x={c.x + 14} y={c.y + 5} fill="#e2e8f0" fontSize="15" fontFamily="Inter, sans-serif" fontWeight="600">{n}</text>
          </g>
        ))}
      </g>
    </svg>
  );
}

export const SCENES = { highway: HighwayScene, warehouse: WarehouseScene, port: PortScene, lastmile: LastMileScene, network: NetworkScene };
export type SceneName = keyof typeof SCENES;
