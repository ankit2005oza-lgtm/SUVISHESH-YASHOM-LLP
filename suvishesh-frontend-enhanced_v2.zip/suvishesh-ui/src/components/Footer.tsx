import { Link } from "react-router-dom";
import { Truck, MapPin, Mail, Phone } from "lucide-react";

export default function Footer() {
  return (
    <footer style={{ background: "var(--navy)", borderTop: "1px solid rgba(56,189,248,0.08)" }}>
      <div className="cx pt-14 pb-8">
        <div className="grid gap-10 md:grid-cols-4 pb-10 border-b border-white/10">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: "var(--grad-btn)" }}>
                <Truck className="h-5 w-5 text-white" strokeWidth={2.5} />
              </div>
              <div>
                <div className="font-display font-bold text-white text-sm">SUVISHESH YASHOM LLP</div>
                <div className="text-[10px] tracking-widest uppercase font-medium" style={{ color: "var(--accent)" }}>Logistics & Supply Chain</div>
              </div>
            </div>
            <p className="text-sm leading-relaxed max-w-sm" style={{ color: "rgba(255,255,255,0.45)" }}>
              Delivering reliability across every mile. Incorporated July 2025 under the
              Registrar of Companies, Delhi — powering India's supply chains with precision and trust.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-widest mb-5">Quick Links</h4>
            <ul className="space-y-2.5 text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>
              {[["/","Home"],["/about","About Us"],["/services","Services"],["/why-us","Why Us"],["/contact","Contact"]].map(([to,label]) => (
                <li key={to}><Link to={to} className="hover:text-white transition-colors">{label}</Link></li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-widest mb-5">Contact</h4>
            <ul className="space-y-3 text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>
              <li className="flex gap-2.5"><MapPin className="h-4 w-4 mt-0.5 shrink-0" style={{ color: "var(--accent)" }} />Delhi, India</li>
              <li className="flex gap-2.5"><Mail className="h-4 w-4 mt-0.5 shrink-0" style={{ color: "var(--accent)" }} />contact@suvisheshyashom.in</li>
              <li className="flex gap-2.5"><Phone className="h-4 w-4 mt-0.5 shrink-0" style={{ color: "var(--accent)" }} />+91 98765 43210</li>
            </ul>
          </div>
        </div>

        <div className="pt-6 flex flex-col md:flex-row justify-between gap-2 text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>
          <p>© {new Date().getFullYear()} Suvishesh Yashom LLP. All rights reserved.</p>
          <p>Incorporated July 2025 · Registrar of Companies, Delhi</p>
        </div>
      </div>
    </footer>
  );
}
