import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Truck, Menu, X } from "lucide-react";

const NAV = [
  { to: "/",         label: "Home" },
  { to: "/about",    label: "About" },
  { to: "/services", label: "Services" },
  { to: "/why-us",   label: "Why Us" },
  { to: "/contact",  label: "Contact" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const loc = useLocation();

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 8);
    fn();
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <header
      className="fixed inset-x-0 top-0 z-50 transition-all duration-300"
      style={{
        background: scrolled ? "rgba(11,17,32,0.98)" : "rgba(11,17,32,0.7)",
        backdropFilter: "blur(16px)",
        borderBottom: scrolled ? "1px solid rgba(56,189,248,0.1)" : "none",
        boxShadow: scrolled ? "0 4px 30px rgba(0,0,0,0.3)" : "none",
      }}
    >
      <div className="cx flex h-16 md:h-20 items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: "var(--grad-btn)", boxShadow: "var(--shadow-btn)" }}>
            <Truck className="h-5 w-5 text-white" strokeWidth={2.5} />
          </div>
          <div className="leading-tight">
            <div className="font-display text-sm font-bold text-white tracking-wide">SUVISHESH YASHOM</div>
            <div className="text-[10px] tracking-[0.25em] uppercase font-medium" style={{ color: "var(--accent)" }}>LLP · Logistics</div>
          </div>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center gap-1">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to}
              className="px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200"
              style={{ color: loc.pathname === n.to ? "var(--accent)" : "rgba(255,255,255,0.7)" }}>
              {n.label}
            </Link>
          ))}
          <Link to="/contact"
            className="ml-3 px-5 py-2.5 rounded-xl text-sm font-semibold text-white transition hover:opacity-85"
            style={{ background: "var(--grad-btn)", boxShadow: "var(--shadow-btn)" }}>
            Get in Touch
          </Link>
        </nav>

        {/* Mobile toggle */}
        <button className="lg:hidden text-white p-2" onClick={() => setOpen(v => !v)}>
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div style={{ background: "var(--navy)", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
          <div className="cx py-4 flex flex-col gap-1">
            {NAV.map((n) => (
              <Link key={n.to} to={n.to} onClick={() => setOpen(false)}
                className="px-4 py-3 rounded-xl text-sm font-medium transition"
                style={{ color: loc.pathname === n.to ? "var(--accent)" : "rgba(255,255,255,0.75)" }}>
                {n.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
