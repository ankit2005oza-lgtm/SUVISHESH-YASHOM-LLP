import React, { useEffect, useRef, useState } from "react";
import { SCENES, SceneName } from "./scenes";

/**
 * Shows /images/<name>.jpg if the file exists, otherwise the illustrated scene.
 * Drop real photos into public/images/ with the same names to replace them.
 */
export function Photo({ name, scene, className = "", children }: {
  name: string; scene: SceneName; className?: string; children?: React.ReactNode;
}) {
  const [ok, setOk] = useState(false);
  const Scene = SCENES[scene];
  return (
    <div className={`relative overflow-hidden ${className}`}>
      <Scene />
      <img
        src={`/images/${name}.jpg`}
        alt=""
        loading="lazy"
        onLoad={(e) => setOk(e.currentTarget.naturalWidth > 10)}
        onError={() => setOk(false)}
        className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ${ok ? "opacity-100" : "opacity-0"}`}
      />
      {children}
    </div>
  );
}

/** Fade/slide-in on scroll */
export function Reveal({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (!("IntersectionObserver" in window)) { setShown(true); return; }
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setShown(true); io.disconnect(); } }, { threshold: 0.12 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={`reveal ${shown ? "reveal-in" : ""} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

/** Photo header used on inner pages */
export function PageHero({ scene, name, eyebrow, title, sub }: {
  scene: SceneName; name: string; eyebrow: string; title: React.ReactNode; sub?: string;
}) {
  return (
    <section className="relative overflow-hidden pt-36 pb-24 md:pb-28" style={{ background: "var(--navy)" }}>
      <Photo name={name} scene={scene} className="!absolute inset-0 kenburns" />
      <div className="absolute inset-0" style={{ background: "linear-gradient(90deg, rgba(11,17,32,0.92) 0%, rgba(11,17,32,0.72) 45%, rgba(11,17,32,0.25) 100%)" }} />
      <div className="absolute inset-x-0 bottom-0 h-24" style={{ background: "linear-gradient(to top, rgba(11,17,32,0.7), transparent)" }} />
      <div className="cx relative z-10">
        <p className="fadeup text-xs font-semibold uppercase tracking-[0.25em] mb-3" style={{ color: "var(--accent)" }}>{eyebrow}</p>
        <h1 className="fadeup d1 font-display text-4xl md:text-6xl font-black text-white max-w-2xl leading-[1.08]">{title}</h1>
        {sub && <p className="fadeup d2 mt-5 max-w-lg text-lg" style={{ color: "rgba(255,255,255,0.65)" }}>{sub}</p>}
      </div>
    </section>
  );
}
