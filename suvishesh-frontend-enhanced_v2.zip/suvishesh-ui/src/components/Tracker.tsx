import { useState } from "react";
import { Search, CheckCircle2, Circle, Loader2, PackageSearch } from "lucide-react";
import { trackShipment, isBackendConfigured } from "../lib/sheetsApi";

interface Step {
  label: string;
  done: boolean;
  active?: boolean;
}

// Demo fallback data so the tracker is interactive even before the
// Google Sheet "Shipments" tab has rows of its own.
const DEMO_TRACKS: Record<string, { status: string; eta: string; steps: Step[] }> = {
  "SY-2025-0042": {
    status: "In Transit",
    eta: "Tomorrow, 3:00 PM",
    steps: [
      { label: "Order Placed — 12 Jun, 9:00 AM", done: true },
      { label: "Picked Up from Origin — 12 Jun, 2:30 PM", done: true },
      { label: "In Transit (Delhi Hub) — 12 Jun, 8:00 PM", done: true, active: true },
      { label: "Out for Delivery — Est. 13 Jun, 10:00 AM", done: false },
      { label: "Delivered — Est. 13 Jun, 3:00 PM", done: false },
    ],
  },
  "SY-2025-0039": {
    status: "Delivered",
    eta: "Delivered 11 Jun",
    steps: [
      { label: "Order Placed — 10 Jun, 8:00 AM", done: true },
      { label: "Picked Up from Origin — 10 Jun, 1:00 PM", done: true },
      { label: "In Transit — 10 Jun, 7:00 PM", done: true },
      { label: "Out for Delivery — 11 Jun, 9:00 AM", done: true },
      { label: "Delivered — 11 Jun, 2:45 PM", done: true },
    ],
  },
};

export default function Tracker() {
  const [id, setId] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ status: string; eta: string; steps: Step[] } | "not-found" | null>(null);

  const handleTrack = async () => {
    const cleaned = id.trim().toUpperCase();
    if (!cleaned) return;
    setLoading(true);
    setResult(null);

    if (isBackendConfigured()) {
      const res = await trackShipment(cleaned);
      setLoading(false);

      if (res.success && res.found) {
        setResult({
          status: res.status || "Unknown",
          eta: res.eta || "—",
          steps: (res.steps || []).map((label, i, arr) => ({
            label,
            done: true,
            active: i === arr.length - 1 && res.status?.toLowerCase() !== "delivered",
          })),
        });
        return;
      }
      if (res.success && !res.found) {
        // fall through to demo data below
      }
    } else {
      await new Promise(r => setTimeout(r, 400));
      setLoading(false);
    }

    setLoading(false);
    const demo = DEMO_TRACKS[cleaned];
    setResult(demo || "not-found");
  };

  return (
    <section className="py-24 bg-white">
      <div className="cx">
        <div className="text-center mb-10">
          <p className="text-xs font-semibold uppercase tracking-[0.25em] mb-3" style={{ color: "var(--accent)" }}>
            Track Shipment
          </p>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-3" style={{ color: "var(--navy)" }}>
            Where's your cargo right now?
          </h2>
          <p className="text-slate-500 max-w-lg mx-auto">
            Enter your tracking ID to get live shipment status.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <div className="flex flex-col sm:flex-row gap-3 mb-8">
            <input
              type="text"
              value={id}
              onChange={e => setId(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleTrack()}
              placeholder="Enter Tracking ID (e.g. SY-2025-0042)"
              className="flex-1 rounded-xl border border-slate-200 bg-white px-5 py-3.5 text-sm focus:outline-none transition-colors"
              onFocus={e => e.target.style.borderColor = "var(--accent)"}
              onBlur={e => e.target.style.borderColor = "#e2e8f0"}
            />
            <button
              onClick={handleTrack}
              disabled={loading}
              className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl text-sm font-semibold text-white transition hover:opacity-85 disabled:opacity-60"
              style={{ background: "var(--grad-btn)", boxShadow: "var(--shadow-btn)" }}
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              Track Now
            </button>
          </div>

          {result === "not-found" && (
            <div className="rounded-2xl border border-slate-100 bg-slate-50 p-8 text-center">
              <PackageSearch className="h-8 w-8 mx-auto mb-3 text-slate-300" />
              <p className="text-sm text-slate-500">No shipment found for <strong>{id.trim().toUpperCase()}</strong>. Please double-check the tracking ID.</p>
            </div>
          )}

          {result && result !== "not-found" && (
            <div className="rounded-2xl border border-slate-100 p-6 md:p-8">
              <div className="flex flex-wrap gap-6 justify-between items-center mb-8 pb-6 border-b border-slate-100">
                <div>
                  <p className="text-[10px] uppercase tracking-widest text-slate-300 mb-1">Tracking ID</p>
                  <p className="font-display font-bold" style={{ color: "var(--accent)" }}>{id.trim().toUpperCase()}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-widest text-slate-300 mb-1">Status</p>
                  <p className="font-display font-bold" style={{ color: "var(--navy)" }}>{result.status}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-widest text-slate-300 mb-1">ETA</p>
                  <p className="font-display font-bold" style={{ color: "var(--navy)" }}>{result.eta}</p>
                </div>
              </div>

              <div className="space-y-0">
                {result.steps.map((step, i) => (
                  <div key={i} className="flex gap-4 relative">
                    {i < result.steps.length - 1 && (
                      <div className="absolute left-[11px] top-7 bottom-0 w-px bg-slate-100" />
                    )}
                    <div className="shrink-0 z-10">
                      {step.done ? (
                        <CheckCircle2
                          className="h-6 w-6"
                          style={{ color: step.active ? "var(--accent)" : "#10B981" }}
                          fill={step.active ? "rgba(56,189,248,0.15)" : "rgba(16,185,129,0.1)"}
                        />
                      ) : (
                        <Circle className="h-6 w-6 text-slate-200" />
                      )}
                    </div>
                    <div className="pb-7">
                      <p className={`text-sm font-medium ${step.done ? "" : "text-slate-300"}`} style={step.done ? { color: "var(--navy)" } : {}}>
                        {step.label}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
