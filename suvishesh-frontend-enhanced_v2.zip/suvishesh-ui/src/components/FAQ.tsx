import { useState } from "react";
import { Plus } from "lucide-react";

const FAQS = [
  {
    q: "What services does Suvishesh Yashom LLP offer?",
    a: "We offer four core services: Freight Management (road, rail & multimodal), Supply Chain Consulting, Warehousing, and Last-Mile Delivery — all operating across India, alongside Customs & Compliance and Reverse Logistics support.",
  },
  {
    q: "Which areas of India do you operate in?",
    a: "Our network spans pan-India — from major metropolitan hubs to tier-2 and tier-3 cities. We are headquartered in Delhi with logistics partners across the country.",
  },
  {
    q: "How can I track my shipment?",
    a: "Use the Track Shipment tool on our website — enter your tracking ID for real-time status updates. You can also contact our support team via WhatsApp or email for live updates.",
  },
  {
    q: "Is Suvishesh Yashom LLP legally registered?",
    a: "Yes. We were incorporated as a Limited Liability Partnership (LLP) on July 3, 2025, registered under the Registrar of Companies, Delhi, and are fully compliant with Indian regulations including GST.",
  },
  {
    q: "How quickly will I get a response after enquiring?",
    a: "We typically respond within one business day. For urgent requirements, reach out directly via WhatsApp or phone — our team is available for active clients around the clock.",
  },
  {
    q: "Can you handle small businesses or just large enterprises?",
    a: "We work with businesses of every size — from growing startups to established enterprises. Our solutions scale with your volume, so you only pay for what you need.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="py-24" style={{ background: "var(--navy2)" }}>
      <div className="cx max-w-3xl">
        <div className="text-center mb-14">
          <p className="text-xs font-semibold uppercase tracking-[0.25em] mb-3" style={{ color: "var(--accent)" }}>
            FAQ
          </p>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-white">
            Frequently asked questions
          </h2>
        </div>

        <div className="space-y-3">
          {FAQS.map((item, i) => {
            const isOpen = open === i;
            return (
              <div key={item.q} className="card overflow-hidden">
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="w-full flex items-center justify-between gap-4 px-6 py-5 text-left"
                >
                  <span className="font-display font-semibold text-sm md:text-base text-white">{item.q}</span>
                  <Plus
                    className="h-5 w-5 shrink-0 transition-transform duration-300"
                    style={{ color: "var(--accent)", transform: isOpen ? "rotate(45deg)" : "rotate(0deg)" }}
                  />
                </button>
                <div
                  className="px-6 overflow-hidden transition-all duration-300 ease-in-out"
                  style={{ maxHeight: isOpen ? "240px" : "0px", paddingBottom: isOpen ? "20px" : "0px" }}
                >
                  <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.5)" }}>{item.a}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
