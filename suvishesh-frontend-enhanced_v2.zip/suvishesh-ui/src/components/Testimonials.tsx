import { Star } from "lucide-react";

const TESTIMONIALS = [
  {
    initials: "RK",
    name: "Rajesh Kumar",
    role: "Operations Head, Agro Fresh Pvt Ltd",
    text: "Suvishesh Yashom handled our entire North India distribution with zero disruption. Real-time tracking and a proactive team — exactly what we needed.",
  },
  {
    initials: "PS",
    name: "Priya Sharma",
    role: "Founder, Craft & Co.",
    text: "Their supply chain consulting saved us 18% on annual freight costs. A genuine partnership approach — they understood our business before proposing anything.",
  },
  {
    initials: "AM",
    name: "Ankit Mehta",
    role: "Director, MedStock India",
    text: "Warehousing setup was seamless from onboarding to daily operations. The inventory accuracy and compliance record has been flawless since day one.",
  },
];

export default function Testimonials() {
  return (
    <section className="py-24 bg-white">
      <div className="cx">
        <div className="text-center mb-14">
          <p className="text-xs font-semibold uppercase tracking-[0.25em] mb-3" style={{ color: "var(--accent)" }}>
            What Clients Say
          </p>
          <h2 className="font-display text-3xl md:text-4xl font-bold" style={{ color: "var(--navy)" }}>
            Trusted by growing businesses
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t) => (
            <div key={t.name} className="rounded-2xl border border-slate-100 p-6 hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
              <div className="flex gap-1 mb-4" style={{ color: "var(--accent)" }}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4" fill="currentColor" strokeWidth={0} />
                ))}
              </div>
              <p className="text-sm text-slate-500 leading-relaxed italic mb-6">"{t.text}"</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center font-display font-bold text-sm text-white shrink-0"
                  style={{ background: "var(--grad-btn)" }}>
                  {t.initials}
                </div>
                <div>
                  <div className="font-semibold text-sm" style={{ color: "var(--navy)" }}>{t.name}</div>
                  <div className="text-xs text-slate-400">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
