import { useState } from "react";
import { PageHero } from "../components/Photo";
import { MapPin, Mail, Phone, Send, Clock, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import { submitLead, isBackendConfigured } from "../lib/sheetsApi";

const inputClass = "w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm focus:outline-none transition-colors";

type Status = "idle" | "loading" | "success" | "error" | "not-configured";

export default function Contact() {
  const [form, setForm] = useState({ name: "", company: "", email: "", phone: "", message: "" });
  const [status, setStatus] = useState<Status>("idle");
  const [errMsg, setErrMsg] = useState("");

  const set = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm(p => ({ ...p, [e.target.name]: e.target.value }));

  const submit = async () => {
    setErrMsg("");

    if (!form.name.trim()) { setErrMsg("Please enter your name."); setStatus("error"); return; }
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      setErrMsg("Please enter a valid email address."); setStatus("error"); return;
    }
    if (!form.message.trim()) { setErrMsg("Please enter a message."); setStatus("error"); return; }

    if (!isBackendConfigured()) {
      // Fallback: open mail client so the enquiry is never lost
      const subject = encodeURIComponent(`Logistics Enquiry from ${form.name} – ${form.company || "Individual"}`);
      const body = encodeURIComponent(
        `Name: ${form.name}\nCompany: ${form.company || "—"}\nEmail: ${form.email}\nPhone: ${form.phone || "—"}\n\nMessage:\n${form.message}`
      );
      window.location.href = `mailto:contact@suvisheshyashom.in?subject=${subject}&body=${body}`;
      setStatus("not-configured");
      return;
    }

    setStatus("loading");
    const res = await submitLead({
      name: form.name.trim(),
      company: form.company.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      message: form.message.trim(),
    });

    if (res.success) {
      setStatus("success");
      setForm({ name: "", company: "", email: "", phone: "", message: "" });
    } else {
      console.error("Lead submission failed:", res.error);
      setErrMsg(
        res.error
          ? `Couldn't reach our server (${res.error}). Please try again or email us directly.`
          : "Something went wrong while sending your message. Please try again or email us directly."
      );
      setStatus("error");
    }
  };

  return (
    <>
      <PageHero scene="lastmile" name="hero-contact" eyebrow="Contact"
        title="Let's talk logistics."
        sub="Share a few details about your requirement — our team typically responds within one business day." />

      <section className="py-24 bg-white">
        <div className="cx grid md:grid-cols-2 gap-16">
          {/* Form */}
          <div>
            <h2 className="font-display text-2xl font-bold mb-8" style={{ color: "var(--navy)" }}>Send us a message</h2>

            {status === "success" && (
              <div className="mb-6 p-4 rounded-xl border text-sm font-medium flex items-start gap-3"
                style={{ background: "rgba(16,185,129,0.06)", borderColor: "rgba(16,185,129,0.25)", color: "#065f46" }}>
                <CheckCircle2 className="h-5 w-5 shrink-0 mt-0.5" />
                <span>Thanks! Your message has been received. Our team will get back to you within one business day.</span>
              </div>
            )}

            {status === "not-configured" && (
              <div className="mb-6 p-4 rounded-xl border text-sm font-medium flex items-start gap-3"
                style={{ background: "rgba(56,189,248,0.06)", borderColor: "rgba(56,189,248,0.25)", color: "#0c4a6e" }}>
                <Mail className="h-5 w-5 shrink-0 mt-0.5" />
                <span>Your email client should open with the details pre-filled. If not, email us directly at contact@suvisheshyashom.in</span>
              </div>
            )}

            {status === "error" && (
              <div className="mb-6 p-4 rounded-xl border text-sm font-medium flex items-start gap-3"
                style={{ background: "rgba(239,68,68,0.06)", borderColor: "rgba(239,68,68,0.25)", color: "#991b1b" }}>
                <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
                <span>{errMsg}</span>
              </div>
            )}

            <div className="space-y-4">
              {[
                { name: "name",    label: "Full Name *",  ph: "Ravi Kumar" },
                { name: "company", label: "Company",      ph: "Your Company Pvt. Ltd." },
                { name: "email",   label: "Email *",      ph: "ravi@company.com" },
                { name: "phone",   label: "Phone",        ph: "+91 98765 43210" },
              ].map(f => (
                <div key={f.name}>
                  <label className="block text-sm font-medium text-slate-600 mb-1">{f.label}</label>
                  <input type="text" name={f.name} value={form[f.name as keyof typeof form]}
                    onChange={set} placeholder={f.ph} className={inputClass}
                    disabled={status === "loading"}
                    onFocus={e => e.target.style.borderColor = "var(--accent)"}
                    onBlur={e => e.target.style.borderColor = "#e2e8f0"} />
                </div>
              ))}
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">Message *</label>
                <textarea name="message" value={form.message} onChange={set} rows={5}
                  placeholder="Tell us about your logistics requirements..."
                  className={inputClass + " resize-none"}
                  disabled={status === "loading"}
                  onFocus={e => e.target.style.borderColor = "var(--accent)"}
                  onBlur={e => e.target.style.borderColor = "#e2e8f0"} />
              </div>
              <button onClick={submit} disabled={status === "loading"}
                className="w-full py-3.5 rounded-xl font-semibold text-white flex items-center justify-center gap-2 transition hover:opacity-85 disabled:opacity-60"
                style={{ background: "var(--grad-btn)", boxShadow: "var(--shadow-btn)" }}>
                {status === "loading"
                  ? <><Loader2 className="h-4 w-4 animate-spin" /> Sending...</>
                  : <><Send className="h-4 w-4" /> Send Message</>}
              </button>
              <p className="text-xs text-slate-400 text-center">
                Your details are stored securely and used only to respond to your enquiry.
              </p>
            </div>
          </div>

          {/* Info */}
          <div>
            <h2 className="font-display text-2xl font-bold mb-8" style={{ color: "var(--navy)" }}>Reach us directly</h2>
            <div className="space-y-5 mb-10">
              {[
                { icon: MapPin, label: "Office", value: "Delhi, India" },
                { icon: Mail,   label: "Email",  value: "contact@suvisheshyashom.in" },
                { icon: Phone,  label: "Phone",  value: "+91 98765 43210" },
              ].map(item => (
                <div key={item.label} className="flex gap-4 items-start">
                  <div className="icon-box">
                    <item.icon className="h-5 w-5" style={{ color: "var(--accent)" }} />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-300 uppercase tracking-widest mb-0.5">{item.label}</p>
                    <p className="font-semibold" style={{ color: "var(--navy)" }}>{item.value}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-2xl p-6 border border-slate-100 bg-slate-50 mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Clock className="h-4 w-4" style={{ color: "var(--accent)" }} />
                <span className="text-sm font-semibold" style={{ color: "var(--navy)" }}>Business Hours</span>
              </div>
              <p className="text-sm text-slate-500 leading-relaxed">
                Monday – Friday: 9:00 AM – 6:00 PM IST<br />
                Saturday: 10:00 AM – 2:00 PM IST<br />
                Sunday: Closed
              </p>
            </div>

            <div className="rounded-2xl overflow-hidden border border-slate-100">
              <iframe
                title="Suvishesh Yashom LLP — Delhi Office"
                src="https://www.google.com/maps?q=New+Delhi,+India&output=embed"
                width="100%" height="220" loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                style={{ border: 0, display: "block" }} />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
