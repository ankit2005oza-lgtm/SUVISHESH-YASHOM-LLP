import { Link } from "react-router-dom";
import { PageHero, Photo, Reveal } from "../components/Photo";
import { ArrowRight, Shield, Users, Globe, Award } from "lucide-react";

const VALUES = [
  { icon: Shield, title: "Trust & Integrity",  desc: "Complete transparency in every transaction and partnership." },
  { icon: Users,  title: "Client First",       desc: "Every decision is centred around delivering value to our clients." },
  { icon: Globe,  title: "Pan-India Reach",    desc: "Our network spans every corner of India for seamless logistics." },
  { icon: Award,  title: "Excellence",         desc: "Highest standards in service quality and regulatory compliance." },
];

export default function About() {
  return (
    <>
      <PageHero scene="warehouse" name="hero-about" eyebrow="About Us"
        title={<>Built on trust.<br />Driven by precision.</>}
        sub="A registered LLP committed to powering India's supply chains." />

      {/* Story */}
      <section className="py-24 bg-white">
        <div className="cx grid md:grid-cols-2 gap-16 items-start">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "var(--accent)" }}>Our Story</p>
            <h2 className="font-display text-3xl font-bold mb-5" style={{ color: "var(--navy)" }}>
              Incorporated to serve India's growing logistics needs
            </h2>
            <p className="text-slate-500 leading-relaxed mb-4">
              Suvishesh Yashom LLP was incorporated on <strong className="text-slate-700">July 3, 2025</strong> under the
              Registrar of Companies, Delhi. Our mission from day one: bring reliability, technology and
              operational excellence to India's logistics sector.
            </p>
            <p className="text-slate-500 leading-relaxed mb-8">
              Led by <strong className="text-slate-700">Sugandh Gulati</strong> and a team of logistics professionals,
              we combine deep industry expertise with modern technology to deliver supply chain solutions
              that scale with your business.
            </p>
            <Link to="/contact" className="inline-flex items-center gap-1.5 text-sm font-semibold" style={{ color: "var(--accent)" }}>
              Work with us <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="rounded-2xl overflow-hidden border border-slate-100 shadow-sm">
            <div className="px-6 py-4" style={{ background: "var(--navy)" }}>
              <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--accent)" }}>Company Details</span>
            </div>
            {[
              ["Entity Type", "Limited Liability Partnership"],
              ["Incorporated", "July 3, 2025"],
              ["Registrar", "RoC, Delhi"],
              ["Status", "Active ✅"],
              ["Industry", "Logistics & Supply Chain"],
              ["Headquarters", "Delhi, India"],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between items-center px-6 py-4 border-b border-slate-100 last:border-0 text-sm">
                <dt className="text-slate-400 font-medium">{k}</dt>
                <dd className="font-semibold text-right" style={{ color: "var(--navy)" }}>{v}</dd>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Vision */}
      <section className="py-20" style={{ background: "var(--navy2)" }}>
        <div className="cx grid md:grid-cols-2 gap-6">
          {[
            { title: "Our Mission", body: "To power India's supply chains with precision, reliability and technology — making world-class logistics accessible to businesses of every size." },
            { title: "Our Vision",  body: "To become India's most trusted logistics partner — known for integrity, innovation and the ability to deliver, every single time." },
          ].map((item) => (
            <div key={item.title} className="card p-8">
              <h3 className="font-display text-xl font-bold text-white mb-4">{item.title}</h3>
              <p className="leading-relaxed" style={{ color: "rgba(255,255,255,0.5)" }}>{item.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-white">
        <div className="cx">
          <div className="text-center mb-12">
            <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: "var(--accent)" }}>What We Stand For</p>
            <h2 className="font-display text-3xl font-bold" style={{ color: "var(--navy)" }}>Our Core Values</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {VALUES.map((v) => (
              <div key={v.title} className="text-center p-6 rounded-2xl border border-slate-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
                <div className="icon-box mx-auto mb-4">
                  <v.icon className="h-5 w-5" style={{ color: "var(--accent)" }} />
                </div>
                <h3 className="font-display font-bold mb-2 text-sm" style={{ color: "var(--navy)" }}>{v.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
