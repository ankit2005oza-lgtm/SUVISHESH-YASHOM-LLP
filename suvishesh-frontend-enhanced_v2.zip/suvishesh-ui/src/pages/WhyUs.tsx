import { Link } from "react-router-dom";
import { PageHero, Photo, Reveal } from "../components/Photo";
import { ShieldCheck, Network, Users, FileCheck, Clock, TrendingUp, ArrowRight } from "lucide-react";

const REASONS = [
  { icon: ShieldCheck, title: "Reliability You Can Count On",  desc: "Our operations are built around SLA adherence and consistent performance metrics." },
  { icon: Network,     title: "Pan-India Network",             desc: "From metros to tier-3 cities, our network covers every corner of India." },
  { icon: Users,       title: "Expert Team",                   desc: "Led by industry veterans with decades of logistics experience." },
  { icon: FileCheck,   title: "Fully Compliant",               desc: "Full compliance with Indian logistics regulations, GST norms and industry standards." },
  { icon: Clock,       title: "On-Time Every Time",            desc: "Real-time tracking and proactive exception management on every shipment." },
  { icon: TrendingUp,  title: "Scalable Solutions",            desc: "10 parcels or 10,000 — our infrastructure scales with your business." },
];

export default function WhyUs() {
  return (
    <>
      <PageHero scene="port" name="hero-whyus" eyebrow="Why Choose Us"
        title="The logistics partner that delivers — always."
        sub="Reliability, compliance and reach — backed by a team that cares." />

      <section className="py-24 bg-white">
        <div className="cx grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {REASONS.map((r) => (
            <div key={r.title} className="flex gap-4 p-6 rounded-2xl border border-slate-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
              <div className="icon-box shrink-0">
                <r.icon className="h-5 w-5" style={{ color: "var(--accent)" }} />
              </div>
              <div>
                <h3 className="font-display font-bold mb-1.5 text-sm" style={{ color: "var(--navy)" }}>{r.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{r.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Stats */}
      <section className="py-20" style={{ background: "var(--navy2)" }}>
        <div className="cx grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[["Pan-India","Coverage"],["100%","Compliance"],["24/7","Support"],["2025","Founded"]].map(([val, label]) => (
            <div key={label} className="card p-6">
              <div className="font-display text-3xl font-black mb-1 grad-text">{val}</div>
              <div className="text-xs uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.4)" }}>{label}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="cx text-center">
          <h2 className="font-display text-3xl font-bold mb-4" style={{ color: "var(--navy)" }}>Ready to experience the difference?</h2>
          <p className="text-slate-500 mb-8">Let's optimise your supply chain today.</p>
          <Link to="/contact"
            className="inline-flex items-center gap-2 px-8 py-4 rounded-xl font-semibold text-white transition hover:opacity-85"
            style={{ background: "var(--grad-btn)", boxShadow: "var(--shadow-btn)" }}>
            Get in Touch <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </>
  );
}
