import { Link } from "react-router-dom";
import type { SceneName } from "../components/scenes";
import { PageHero, Photo, Reveal } from "../components/Photo";
import { Truck, BarChart3, Warehouse, MapPin, Package, RefreshCw, ArrowRight } from "lucide-react";

const SERVICES: { icon: any; scene: SceneName; img: string; title: string; desc: string; features: string[] }[] = [
  { icon: Truck, scene: "highway", img: "service-freight", title: "Freight Management",      desc: "End-to-end road, rail and multimodal freight across India.", features: ["Full Truckload (FTL)", "Less Than Truckload (LTL)", "Multimodal Transport", "Real-time Tracking"] },
  { icon: BarChart3, scene: "network", img: "service-consulting", title: "Supply Chain Consulting", desc: "Data-driven strategy to optimise cost, speed and resilience.", features: ["Process Optimization", "Cost Reduction", "Risk Assessment", "Tech Integration"] },
  { icon: Warehouse, scene: "warehouse", img: "service-warehouse", title: "Warehousing",             desc: "Strategically located storage with full inventory visibility.", features: ["Inventory Management", "Pick & Pack", "Cold Storage", "24/7 Security"] },
  { icon: MapPin, scene: "lastmile", img: "service-lastmile", title: "Last-Mile Delivery",      desc: "Fast, trackable delivery to your customer's doorstep.", features: ["Same Day Delivery", "Proof of Delivery", "Customer Alerts", "Return Management"] },
  { icon: Package, scene: "port", img: "service-customs", title: "Customs & Compliance",   desc: "Navigate complex regulations with zero liability for you.", features: ["Documentation Support", "Regulatory Compliance", "Audit Readiness", "GST Compliance"] },
  { icon: RefreshCw, scene: "warehouse", img: "service-reverse", title: "Reverse Logistics",       desc: "Efficient returns management that reduces costs.", features: ["Returns Processing", "Refurbishment", "Disposal Management", "Analytics"] },
];

export default function Services() {
  return (
    <>
      <PageHero scene="highway" name="hero-services" eyebrow="What We Do"
        title="Services that move your business forward"
        sub="Freight, warehousing, consulting and last-mile — one accountable partner." />

      <section className="py-24 bg-white">
        <div className="cx grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES.map((s, i) => (
            <Reveal key={s.title} delay={(i % 3) * 110}>
            <div className="photo-card h-full rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300 flex flex-col bg-white">
              <div className="relative h-48 overflow-hidden">
                <Photo name={s.img} scene={s.scene} className="!absolute inset-0 zoom" />
                <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(11,17,32,0.75), transparent 60%)" }} />
                <div className="icon-box absolute bottom-3 left-5 backdrop-blur" style={{ background: "rgba(11,17,32,0.7)" }}>
                  <s.icon className="h-5 w-5" style={{ color: "var(--accent)" }} />
                </div>
              </div>
              <div className="p-6 flex-1">
                <h3 className="font-display font-bold text-lg mb-2" style={{ color: "var(--navy)" }}>{s.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed mb-5">{s.desc}</p>
                <ul className="space-y-2">
                  {s.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm text-slate-500">
                      <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: "var(--accent)" }} />{f}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="py-20" style={{ background: "var(--navy2)" }}>
        <div className="cx text-center">
          <h2 className="font-display text-3xl font-bold text-white mb-4">Need a custom logistics solution?</h2>
          <p className="mb-8" style={{ color: "rgba(255,255,255,0.5)" }}>Talk to our team — we'll design a plan for your exact needs.</p>
          <Link to="/contact"
            className="inline-flex items-center gap-2 px-8 py-4 rounded-xl font-semibold text-white transition hover:opacity-85"
            style={{ background: "var(--grad-btn)", boxShadow: "var(--shadow-btn)" }}>
            Contact Us <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </>
  );
}
