import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Truck, BarChart3, Warehouse, MapPin, ArrowRight, ShieldCheck, Globe, Clock, Award, PackageCheck, PhoneCall, Route, CheckCircle2 } from "lucide-react";
import { Photo, Reveal } from "../components/Photo";
import type { SceneName } from "../components/scenes";
import Counter from "../components/Counter";
import Tracker from "../components/Tracker";
import Testimonials from "../components/Testimonials";
import FAQ from "../components/FAQ";

const SERVICES: { icon: any; title: string; desc: string; scene: SceneName; img: string }[] = [
  { icon: Truck,     scene: "highway",   img: "service-freight",   title: "Freight Management",      desc: "End-to-end road, rail & multimodal freight across India with real-time tracking." },
  { icon: BarChart3, scene: "network",   img: "service-consulting", title: "Supply Chain Consulting", desc: "Data-driven strategy to optimise cost, speed and resilience of your supply chain." },
  { icon: Warehouse, scene: "warehouse", img: "service-warehouse",  title: "Warehousing",             desc: "Strategically located storage with full inventory visibility and 24/7 security." },
  { icon: MapPin,    scene: "lastmile",  img: "service-lastmile",   title: "Last-Mile Delivery",      desc: "Fast, trackable delivery to your customer's doorstep, every single time." },
];

const TRUST = [
  { icon: ShieldCheck, label: "100% Compliant" },
  { icon: Globe,       label: "Pan-India Network" },
  { icon: Clock,       label: "24/7 Support" },
  { icon: Award,       label: "Expert Team" },
];


const SLIDES: { scene: SceneName; img: string; caption: string }[] = [
  { scene: "highway",   img: "hero-1", caption: "Highway freight" },
  { scene: "port",      img: "hero-2", caption: "Ports & multimodal" },
  { scene: "warehouse", img: "hero-3", caption: "Smart warehousing" },
  { scene: "lastmile",  img: "hero-4", caption: "Last-mile delivery" },
];

const STEPS = [
  { icon: PhoneCall,    title: "Share your requirement", desc: "Tell us what, where and when. We respond within one business day." },
  { icon: Route,        title: "We plan the route",      desc: "Optimal mode, lane and warehouse plan — priced transparently." },
  { icon: Truck,        title: "Pickup & transit",       desc: "Verified fleet, live tracking and proactive exception alerts." },
  { icon: PackageCheck, title: "Delivered with proof",   desc: "Doorstep delivery with digital proof of delivery, every time." },
];

const CITIES = ["Delhi NCR", "Mumbai", "Bengaluru", "Hyderabad", "Chennai", "Kolkata", "Ahmedabad", "Pune", "Jaipur", "Lucknow", "Chandigarh", "Indore", "Kochi", "Nagpur", "Surat", "Patna"];

function HeroSlides() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % SLIDES.length), 6500);
    return () => clearInterval(t);
  }, []);
  return (
    <>
      <div className="absolute inset-0">
        {SLIDES.map((s, idx) => (
          <div key={s.img} className="absolute inset-0 transition-opacity duration-[1600ms]" style={{ opacity: idx === i ? 1 : 0 }}>
            <Photo name={s.img} scene={s.scene} className="!absolute inset-0 kenburns" />
          </div>
        ))}
      </div>
      {/* readability overlays */}
      <div className="absolute inset-0" style={{ background: "linear-gradient(90deg, rgba(11,17,32,0.92) 0%, rgba(11,17,32,0.7) 40%, rgba(11,17,32,0.1) 100%)" }} />
      <div className="absolute inset-x-0 bottom-0 h-40" style={{ background: "linear-gradient(to top, rgba(11,17,32,0.95), transparent)" }} />
      {/* slide dots */}
      <div className="absolute bottom-28 right-6 md:right-12 z-20 hidden sm:flex flex-col items-end gap-2">
        <span className="text-[11px] uppercase tracking-[0.25em] text-white/60">{SLIDES[i].caption}</span>
        <div className="flex gap-2">
          {SLIDES.map((s, idx) => (
            <button key={s.img} aria-label={s.caption} onClick={() => setI(idx)}
              className="h-1.5 rounded-full transition-all duration-500"
              style={{ width: idx === i ? 36 : 12, background: idx === i ? "var(--accent)" : "rgba(255,255,255,0.35)" }} />
          ))}
        </div>
      </div>
    </>
  );
}

export default function Home() {
  return (
    <>
      {/* ── HERO ── */}
      <section className="relative min-h-screen flex items-center overflow-hidden" style={{ background: "var(--navy)" }}>
        <HeroSlides />

        <div className="cx relative z-10 pt-32 pb-40 grid lg:grid-cols-[1.25fr_1fr] gap-10 items-center">
          <div>
            <div className="fadeup">
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-semibold mb-6 border backdrop-blur"
                style={{ color: "var(--accent)", borderColor: "rgba(56,189,248,0.3)", background: "rgba(56,189,248,0.1)" }}>
                <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: "var(--accent)" }} />
                Registered · RoC Delhi · July 2025
              </span>
            </div>

            <h1 className="font-display text-5xl sm:text-6xl md:text-7xl font-black text-white leading-[1.05] max-w-4xl mb-6 fadeup d1">
              Delivering <span className="grad-text">Reliability</span><br />Across Every Mile.
            </h1>

            <p className="text-lg max-w-xl mb-10 leading-relaxed fadeup d2" style={{ color: "rgba(255,255,255,0.7)" }}>
              Suvishesh Yashom LLP powers India's supply chains with precision freight,
              intelligent warehousing and last-mile execution — built on trust and technology.
            </p>

            <div className="flex flex-wrap gap-4 fadeup d3">
              <Link to="/contact"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:opacity-90"
                style={{ background: "var(--grad-btn)", boxShadow: "var(--shadow-btn)" }}>
                Get in Touch <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/services"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl text-sm font-semibold border backdrop-blur transition hover:border-white/50 hover:bg-white/10"
                style={{ color: "rgba(255,255,255,0.9)", borderColor: "rgba(255,255,255,0.25)" }}>
                Our Services
              </Link>
            </div>

            <div className="flex flex-wrap gap-3 mt-12 fadeup d4">
              {TRUST.map((t) => (
                <div key={t.label}
                  className="flex items-center gap-2 px-4 py-2 rounded-full text-xs border backdrop-blur"
                  style={{ color: "rgba(255,255,255,0.75)", borderColor: "rgba(255,255,255,0.14)", background: "rgba(255,255,255,0.06)" }}>
                  <t.icon className="h-3.5 w-3.5" style={{ color: "var(--accent)" }} />
                  {t.label}
                </div>
              ))}
            </div>
          </div>

          {/* Floating glass cards */}
          <div className="relative hidden lg:block h-[420px] fadeup d3">
            <div className="glass floaty absolute right-0 top-4 w-[330px] rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-white/50">Live shipment</div>
                  <div className="font-display font-bold text-white text-sm mt-0.5">SY-2025-0412</div>
                </div>
                <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full" style={{ background: "rgba(16,185,129,0.15)", color: "#34d399" }}>In Transit</span>
              </div>
              <div className="flex items-center justify-between text-xs text-white/70 mb-2"><span>Delhi</span><span>Mumbai</span></div>
              <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div className="grow h-full rounded-full" style={{ ["--w" as any]: "68%", background: "var(--grad-btn)" }} />
              </div>
              <div className="flex items-center justify-between mt-3 text-[11px] text-white/50">
                <span>Picked up · 12 Jun</span><span>ETA 14 Jun</span>
              </div>
            </div>

            <div className="glass floaty-2 absolute left-0 bottom-6 w-[230px] rounded-2xl p-5">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ background: "rgba(16,185,129,0.18)" }}>
                  <CheckCircle2 className="h-5 w-5" style={{ color: "#34d399" }} />
                </div>
                <div>
                  <div className="font-display text-2xl font-black text-white leading-none">99%</div>
                  <div className="text-[11px] text-white/55 mt-1">On-time delivery</div>
                </div>
              </div>
            </div>

            <div className="glass floaty absolute right-8 bottom-[-6px] rounded-2xl px-4 py-3 flex items-center gap-2.5">
              <Globe className="h-4 w-4" style={{ color: "var(--accent)" }} />
              <span className="text-xs text-white/80 font-medium">50+ cities connected</span>
            </div>
          </div>
        </div>
      </section>

      {/* ── ANIMATED STATS STRIP (overlaps hero) ── */}
      <section id="stats" className="relative z-20 -mt-20 pb-6">
        <div className="cx">
          <div className="rounded-3xl bg-white border border-slate-100 grid grid-cols-2 md:grid-cols-4 text-center overflow-hidden"
            style={{ boxShadow: "0 30px 80px rgba(11,17,32,0.18)" }}>
            {[
              { value: 500, suffix: "+", label: "Shipments Delivered", icon: PackageCheck },
              { value: 50,  suffix: "+", label: "Cities Covered",      icon: MapPin },
              { value: 99,  suffix: "%", label: "On-Time Delivery",    icon: Clock },
              { value: 24,  suffix: "/7", label: "Customer Support",   icon: PhoneCall },
            ].map((s, idx) => (
              <div key={s.label} className={`py-9 px-4 ${idx % 2 === 1 ? "border-l border-slate-100" : ""} ${idx > 1 ? "border-t md:border-t-0 border-slate-100" : ""} ${idx === 2 ? "md:border-l" : ""}`}>
                <s.icon className="h-5 w-5 mx-auto mb-3" style={{ color: "var(--accent)" }} />
                <div className="font-display text-3xl md:text-4xl font-black mb-1" style={{ color: "var(--navy)" }}>
                  <Counter target={s.value} suffix={s.suffix} />
                </div>
                <div className="text-[11px] uppercase tracking-widest text-slate-400">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── ABOUT STRIP ── */}
      <section className="py-24 bg-white overflow-hidden">
        <div className="cx flex flex-col lg:flex-row gap-16 items-center">
          <Reveal className="flex-1">
            <p className="text-xs font-semibold uppercase tracking-[0.25em] mb-3" style={{ color: "var(--accent)" }}>Who We Are</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold leading-snug mb-5" style={{ color: "var(--navy)" }}>
              A new-generation logistics partner,<br />built for modern India.
            </h2>
            <p className="leading-relaxed mb-7 max-w-lg text-slate-500">
              Incorporated in July 2025 under the Registrar of Companies, Delhi,
              Suvishesh Yashom LLP brings operational rigour and technology together to deliver
              dependable logistics outcomes — from a single shipment to enterprise-scale supply chains.
            </p>
            <ul className="grid sm:grid-cols-2 gap-3 mb-8 max-w-lg">
              {["Verified, compliant fleet", "Live shipment tracking", "Transparent pricing", "Dedicated account manager"].map((t) => (
                <li key={t} className="flex items-center gap-2 text-sm text-slate-600">
                  <CheckCircle2 className="h-4 w-4 shrink-0" style={{ color: "var(--green)" }} />{t}
                </li>
              ))}
            </ul>
            <Link to="/about"
              className="inline-flex items-center gap-1.5 text-sm font-semibold transition hover:gap-3"
              style={{ color: "var(--accent)" }}>
              Learn about us <ArrowRight className="h-4 w-4" />
            </Link>
          </Reveal>

          <Reveal className="flex-1 w-full" delay={150}>
            <div className="relative max-w-xl mx-auto">
              <div className="absolute -inset-4 rounded-[2rem] -z-10 opacity-20 blur-2xl" style={{ background: "var(--grad)" }} />
              <Photo name="about" scene="warehouse" className="aspect-[4/3] rounded-3xl shadow-2xl" />
              <div className="absolute -bottom-6 -left-4 sm:-left-8 rounded-2xl bg-white px-5 py-4 flex items-center gap-3 floaty" style={{ boxShadow: "0 20px 50px rgba(11,17,32,0.2)" }}>
                <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ background: "var(--grad-btn)" }}>
                  <ShieldCheck className="h-5 w-5 text-white" />
                </div>
                <div>
                  <div className="font-display font-black text-lg leading-none" style={{ color: "var(--navy)" }}>100%</div>
                  <div className="text-[11px] text-slate-400 mt-1 uppercase tracking-wider">Compliant</div>
                </div>
              </div>
              <div className="absolute -top-5 -right-3 sm:-right-6 rounded-2xl px-5 py-4 text-center floaty-2" style={{ background: "var(--navy)", boxShadow: "0 20px 50px rgba(11,17,32,0.3)" }}>
                <div className="font-display font-black text-2xl text-white leading-none">2025</div>
                <div className="text-[10px] mt-1 uppercase tracking-widest" style={{ color: "var(--accent)" }}>Est. Delhi</div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ── SERVICES ── */}
      <section className="py-24" style={{ background: "var(--navy2)" }}>
        <div className="cx">
          <Reveal className="text-center mb-14">
            <p className="text-xs font-semibold uppercase tracking-[0.25em] mb-3" style={{ color: "var(--accent)" }}>What We Do</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold text-white">
              Services that move your business forward
            </h2>
          </Reveal>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
            {SERVICES.map((s, i) => (
              <Reveal key={s.title} delay={i * 100}>
                <Link to="/services" className="card photo-card block h-full overflow-hidden">
                  <div className="relative h-44 overflow-hidden">
                    <Photo name={s.img} scene={s.scene} className="!absolute inset-0 zoom" />
                    <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(17,24,39,1), rgba(17,24,39,0.1) 70%)" }} />
                    <div className="icon-box absolute bottom-3 left-5 backdrop-blur" style={{ background: "rgba(11,17,32,0.7)" }}>
                      <s.icon className="h-5 w-5" style={{ color: "var(--accent)" }} />
                    </div>
                  </div>
                  <div className="p-6 pt-4">
                    <h3 className="font-display font-bold text-white mb-2 text-sm">{s.title}</h3>
                    <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.5)" }}>{s.desc}</p>
                    <span className="inline-flex items-center gap-1 mt-4 text-xs font-semibold" style={{ color: "var(--accent)" }}>Learn more <ArrowRight className="h-3.5 w-3.5" /></span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link to="/services"
              className="inline-flex items-center gap-2 text-sm font-semibold transition"
              style={{ color: "var(--accent)" }}>
              View all services <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section className="py-24 bg-slate-50">
        <div className="cx">
          <Reveal className="text-center mb-16">
            <p className="text-xs font-semibold uppercase tracking-[0.25em] mb-3" style={{ color: "var(--accent)" }}>How It Works</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold" style={{ color: "var(--navy)" }}>From request to doorstep in four steps</h2>
          </Reveal>
          <div className="relative grid md:grid-cols-4 gap-8">
            <div className="hidden md:block absolute top-8 left-[12%] right-[12%] h-px border-t-2 border-dashed border-sky-200" />
            {STEPS.map((st, i) => (
              <Reveal key={st.title} delay={i * 120} className="relative text-center">
                <div className="relative mx-auto w-16 h-16 rounded-2xl flex items-center justify-center mb-5 text-white"
                  style={{ background: "var(--grad-btn)", boxShadow: "var(--shadow-btn)" }}>
                  <st.icon className="h-7 w-7" />
                  <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-white text-[11px] font-black flex items-center justify-center border border-slate-200" style={{ color: "var(--navy)" }}>{i + 1}</span>
                </div>
                <h3 className="font-display font-bold text-sm mb-2" style={{ color: "var(--navy)" }}>{st.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed max-w-[15rem] mx-auto">{st.desc}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ── PAN-INDIA NETWORK ── */}
      <section className="relative overflow-hidden" style={{ background: "var(--navy)" }}>
        <Photo name="network" scene="network" className="!absolute inset-0" />
        <div className="absolute inset-0" style={{ background: "linear-gradient(90deg, rgba(11,17,32,0.96) 0%, rgba(11,17,32,0.75) 40%, rgba(11,17,32,0.1) 100%)" }} />
        <div className="cx relative z-10 py-28 min-h-[560px] flex items-center">
          <Reveal className="max-w-lg">
            <p className="text-xs font-semibold uppercase tracking-[0.25em] mb-3" style={{ color: "var(--accent)" }}>Our Network</p>
            <h2 className="font-display text-3xl md:text-5xl font-black text-white leading-tight mb-5">
              One partner.<br /><span className="grad-text">Every corner of India.</span>
            </h2>
            <p className="mb-8 leading-relaxed" style={{ color: "rgba(255,255,255,0.65)" }}>
              From metro hubs to tier-3 towns, our connected network of fleets, warehouses and delivery partners
              keeps your goods moving on a single, trackable platform.
            </p>
            <div className="flex gap-8">
              {[["50+", "Cities"], ["9", "Hub regions"], ["24/7", "Operations"]].map(([v, l]) => (
                <div key={l}>
                  <div className="font-display text-3xl font-black text-white">{v}</div>
                  <div className="text-[11px] uppercase tracking-widest text-white/50 mt-1">{l}</div>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
        {/* cities marquee */}
        <div className="marquee relative z-10 border-t border-white/10 py-4 overflow-hidden" style={{ background: "rgba(11,17,32,0.85)" }}>
          <div className="marquee-track">
            {[...CITIES, ...CITIES].map((c, i) => (
              <span key={i} className="flex items-center gap-3 px-6 text-sm font-medium text-white/60 whitespace-nowrap">
                <MapPin className="h-3.5 w-3.5" style={{ color: "var(--accent)" }} />{c}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHY US STRIP ── */}
      <section className="py-20 bg-white">
        <div className="cx text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.25em] mb-3" style={{ color: "var(--accent)" }}>Why Choose Us</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4" style={{ color: "var(--navy)" }}>
            The logistics partner that delivers — always.
          </h2>
          <p className="text-slate-500 max-w-lg mx-auto mb-10">
            Reliability, compliance and pan-India reach — backed by a team that's passionate about logistics.
          </p>
          <Link to="/why-us"
            className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl text-sm font-semibold text-white transition hover:opacity-85"
            style={{ background: "var(--grad-btn)", boxShadow: "var(--shadow-btn)" }}>
            See Why We're Different <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* ── TRACK SHIPMENT ── */}
      <Tracker />

      {/* ── TESTIMONIALS ── */}
      <Testimonials />

      {/* ── FAQ ── */}
      <FAQ />

      {/* ── CTA ── */}
      <section className="py-28 relative overflow-hidden" style={{ background: "var(--navy)" }}>
        <Photo name="cta" scene="port" className="!absolute inset-0 kenburns" />
        <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(11,17,32,0.82), rgba(11,17,32,0.9))" }} />
        <Reveal className="cx text-center relative z-10">
          <h2 className="font-display text-3xl md:text-5xl font-black text-white mb-4">
            Ready to move smarter?<br /><span className="grad-text">Let's talk logistics.</span>
          </h2>
          <p className="mb-10 max-w-md mx-auto" style={{ color: "rgba(255,255,255,0.65)" }}>
            Tell us about your supply chain — we'll build a plan that delivers results.
          </p>
          <Link to="/contact"
            className="inline-flex items-center gap-2 px-8 py-4 rounded-xl font-semibold text-white transition hover:-translate-y-0.5 hover:opacity-90"
            style={{ background: "var(--grad-btn)", boxShadow: "var(--shadow-btn)" }}>
            Get in Touch <ArrowRight className="h-4 w-4" />
          </Link>
        </Reveal>
      </section>
    </>
  );
}
