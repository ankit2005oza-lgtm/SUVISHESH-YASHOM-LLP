# Suvishesh Yashom LLP — Website

A modern logistics company website (React + Vite + TypeScript + Tailwind),
now enhanced with animated stats, testimonials, FAQ, a shipment tracker,
a floating WhatsApp button, and a **Google Sheets backend** for the
contact form & shipment tracking.

---

## ✅ Run locally

```bash
npm install
npm run dev
```

Opens at **http://localhost:5173**

Works out of the box even **without** the backend — the contact form falls
back to opening the visitor's email client if no Google Sheets URL is set.

---

## 🔗 Connect the Google Sheets backend (recommended)

This gives you a free, no-server backend: every contact form submission is
saved as a row in a Google Sheet, and the Track Shipment tool reads shipment
statuses from another tab in the same sheet.

### Step 1 — Create the Sheet
1. Go to [sheets.new](https://sheets.new) to create a new Google Sheet.
2. (Optional) Rename it, e.g. "Suvishesh Yashom — Leads & Tracking".

### Step 2 — Add the Apps Script
1. In the Sheet, open **Extensions → Apps Script**.
2. Delete the placeholder code.
3. Open `apps-script/Code.gs` from this project, copy **all** of it, and
   paste it into the Apps Script editor.
4. Click **Save** (Ctrl/Cmd + S).

### Step 3 — Deploy as a Web App
1. Click **Deploy → New deployment**.
2. Click the gear icon ⚙️ next to "Select type" → choose **Web app**.
3. Settings:
   - **Execute as:** Me
   - **Who has access:** Anyone
4. Click **Deploy**, then **Authorize access** (grant permission to your
   own Google account — this is normal for Apps Script).
5. Copy the **Web app URL** — looks like:
   `https://script.google.com/macros/s/AKfycb.../exec`

### Step 4 — Connect it to the website
1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Paste your Web App URL:
   ```
   VITE_SHEETS_API_URL=https://script.google.com/macros/s/AKfycb.../exec
   ```
3. (Optional) Set your WhatsApp number for the floating chat button:
   ```
   VITE_WHATSAPP_NUMBER=919876543210
   ```
4. Restart the dev server: `npm run dev`

### How data shows up
- The script auto-creates a **"Leads"** tab on first submission, with
  columns: `Timestamp | Name | Company | Email | Phone | Message | Status`.
- To enable shipment tracking, create a **"Shipments"** tab with columns:
  `TrackingID | Status | ETA | Step1 | Step2 | Step3 | Step4 | Step5`
  — fill `StepN` columns with the timeline text shown to customers
  (e.g. "Picked Up from Origin — 12 Jun, 2:30 PM").

### 🩺 Quick diagnostic
Open this in your browser (replace with your deployment URL):
```
https://script.google.com/macros/s/XXXXXXXX/exec?action=test
```
You should see:
```json
{"success":true,"message":"Backend is connected!","spreadsheet":"...","sheets":["Leads","Shipments"]}
```
If you see this, the backend is working correctly — submit the contact form
on the website and refresh your Sheet, a new row should appear in "Leads".

If the contact form still shows an error after that, open the browser
console (F12 → Console tab) while submitting — the error message shown
there (and in the red banner on the form) will say exactly what went wrong.

> ⚠️ Whenever you edit `Code.gs` again, go to **Deploy → Manage deployments**
> → edit (pencil icon) → **Version: New version** → Deploy, otherwise your
> changes won't go live.

---

## 🚀 Deploy to Vercel

1. Push this project to GitHub.
2. Import it on [vercel.com](https://vercel.com).
3. In Vercel → Project Settings → Environment Variables, add:
   - `VITE_SHEETS_API_URL`
   - `VITE_WHATSAPP_NUMBER`
4. Deploy — done!

---

## 📄 Pages & Sections

- `/` — Home (hero, animated stats, services, shipment tracker,
  testimonials, FAQ, CTA)
- `/about` — About Us (company story, mission & vision, values)
- `/services` — Services (6 detailed service cards)
- `/why-us` — Why Choose Us (differentiators + stats)
- `/contact` — Contact (form → Google Sheets backend, office info, map)

## 🆕 What's new in this version

- **Google Sheets backend** (`apps-script/Code.gs` + `src/lib/sheetsApi.ts`)
  for contact form leads and shipment tracking — no server required.
- **Animated stat counters** on the homepage.
- **Shipment Tracker** widget with live lookup + demo fallback data.
- **Testimonials** section with client reviews.
- **FAQ** accordion with common questions.
- **Floating WhatsApp button** for instant chat.
- **Improved Contact form** with loading/success/error states and a
  Google Map embed.
